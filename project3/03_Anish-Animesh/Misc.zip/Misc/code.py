import numpy as np 
import pandas as pd
from sklearn.model_selection import train_test_split
import keras
from keras.models import Sequential
from keras.layers import Conv2D, MaxPooling2D
from vgg16 import VGG16
from keras.applications.vgg16 import preprocess_input
from keras.preprocessing.image import img_to_array, array_to_img
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from mpl_toolkits.mplot3d import Axes3D
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neural_network import MLPClassifier
from scipy import linalg
import sklearn.discriminant_analysis
from sklearn.metrics import accuracy_score

train = pd.read_csv('fashion-mnist_train.csv')
test = pd.read_csv('fashion-mnist_test.csv')

train_X = np.array(train.iloc[:, 1:])
test_X = np.array(test.iloc[:, 1:])
train_Y = np.array(train.iloc[:, 0]) 
test_Y = np.array(test.iloc[:, 0]) 

classes = np.unique(train_Y)
num_classes = len(classes)

train_X = np.dstack([train_X] * 3)
test_X = np.dstack([test_X] * 3)

train_X = train_X.reshape(-1, 28, 28, 3)
test_X = test_X.reshape (-1, 28, 28, 3)

train_X = np.asarray([img_to_array(array_to_img(im, scale = False).resize((48, 48))) for im in train_X])
test_X = np.asarray([img_to_array(array_to_img(im, scale = False).resize((48, 48))) for im in test_X])

train_X = train_X / 255.
test_X = test_X / 255.
train_X = train_X.astype('float32')
test_X = test_X.astype('float32')

train_X, valid_X, train_Y, val_Y = train_test_split(train_X, train_Y, test_size = 0.2, random_state = 13)

IMG_WIDTH = 48
IMG_HEIGHT = 48
IMG_DEPTH = 3
BATCH_SIZE = 32

train_X = preprocess_input(train_X)
valid_X = preprocess_input(valid_X)
test_X  = preprocess_input(test_X)

model = VGG16(weights = 'imagenet', include_top = False, input_shape = (IMG_HEIGHT, IMG_WIDTH, IMG_DEPTH))
conv_base.summary()

train_features = model.predict(np.array(train_X), batch_size = BATCH_SIZE, verbose = 1)
test_features = model.predict(np.array(test_X), batch_size = BATCH_SIZE, verbose = 1)
val_features = model.predict(np.array(valid_X), batch_size = BATCH_SIZE, verbose = 1)

train_features_vgg = np.reshape(train_features, (48000, 512))
test_features_vgg = np.reshape(test_features, (10000, 512))
val_features_vgg = np.reshape(val_features, (12000, 512))

pca_train_features = StandardScaler().fit_transform(train_features_vgg)
pca = PCA(n_components = 3)
pca_train_features = pca.fit_transform(pca_train_features)

KMC = KMeans(n_clusters = 10)
KMC.fit(pca_train_features)

fig = plt.figure(1,figsize=(8,6))
plt.clf()
plt.cla()
ax.scatter(pca_train_features[:,[0]],pca_train_features[:,[1]],pca_train_features[:,[2]],c=KMC.labels_.astype(np.float))
plt.savefig('fmnist-train.png')

pca_test_features = StandardScaler().fit_transform(test_features_vgg)
pca = PCA(n_components = 3)
pca_test_features = pca.fit_transform(pca_test_features)

KMC = KMeans(n_clusters = 10)
KMC.fit(pca_test_features)

fig = plt.figure(1,figsize=(8,6))
plt.clf()
ax = Axes3D(fig, rect = [0,0,0.95,1],elev = 48,azim = 134)

plt.cla()
ax.scatter(pca_test_features[:,[0]], pca_test_features[:,[1]], pca_test_features[:,[2]], c = KMC.labels_.astype(np.float))
plt.savefig('fmnist-test.png')

pca_val_features = StandardScaler().fit_transform(val_features_vgg)
pca = PCA(n_components = 3)
pca_val_features = pca.fit_transform(pca_val_features)

KMC = KMeans(n_clusters = 10)
KMC.fit(pca_val_features)

fig = plt.figure(1,figsize=(8,6))
plt.clf()
ax = Axes3D(fig, rect = [0,0,0.95,1],elev = 48,azim = 134)

plt.cla()
ax.scatter(pca_val_features[:,[0]], pca_val_features[:,[1]], pca_val_features[:,[2]], c = KMC.labels_.astype(np.float))
plt.show()

LR = LogisticRegression()
LR.fit(train_features_vgg, train_Y)
LR.score(val_features_vgg, val_Y)
LR.score(test_features_vgg, test_Y)

RF = RandomForestClassifier(n_estimators = 25, criterion = 'gini')
RF.fit(train_features_vgg, train_Y)
RF.score(val_features_vgg, val_Y)
RF.score(test_features_vgg, test_Y)

RF = RandomForestClassifier(n_estimators = 50, criterion = 'gini')
RF.fit(train_features_vgg, train_Y)
RF.score(val_features_vgg, val_Y)
RF.score(test_features_vgg, test_Y)

RF = RandomForestClassifier(n_estimators = 100, criterion = 'gini')
RF.fit(train_features_vgg, train_Y)
RF.score(val_features_vgg, val_Y)
RF.score(test_features_vgg, test_Y)

RF = RandomForestClassifier(n_estimators = 25, criterion = 'entropy')
RF.fit(train_features_vgg, train_Y)
RF.score(val_features_vgg, val_Y)
RF.score(test_features_vgg, test_Y)

RF = RandomForestClassifier(n_estimators = 50, criterion = 'entropy')
RF.fit(train_features_vgg, train_Y)
RF.score(val_features_vgg, val_Y)
RF.score(test_features_vgg, test_Y)

RF = RandomForestClassifier(n_estimators = 100, criterion = 'entropy')
RF.fit(train_features_vgg, train_Y)
RF.score(val_features_vgg, val_Y)
RF.score(test_features_vgg, test_Y)

KNN = KNeighborsClassifier(n_neighbors = 3)
KNN.fit(train_features_vgg, train_Y)
KNN.score(val_features_vgg, val_Y)
KNN.score(test_features_vgg, test_Y)

KNN = KNeighborsClassifier(n_neighbors = 5)
KNN.fit(train_features_vgg, train_Y)
KNN.score(val_features_vgg, val_Y)
KNN.score(test_features_vgg, test_Y)

MLP = MLPClassifier(hidden_layer_sizes=(64,32), activation='relu', batch_size=64)
MLP.fit(train_features_vgg, train_Y)
MLP.score(val_features_vgg, val_Y)
MLP.score(test_features_vgg, test_Y)

train = pd.read_csv('mnist_train.csv')
test = pd.read_csv('mnist_test.csv')

train_X = np.array(train.iloc[:, 1:])
test_X = np.array(test.iloc[:, 1:])
train_Y = np.array(train.iloc[:, 0]) 
test_Y = np.array(test.iloc[:, 0]) 

train_X = np.dstack([train_X] * 3)
test_X = np.dstack([test_X] * 3)
train_X.shape, test_X.shape

train_X = train_X.reshape(-1, 28, 28, 3)
test_X = test_X.reshape (-1, 28, 28, 3)

train_X = np.asarray([img_to_array(array_to_img(im, scale = False).resize((48, 48))) for im in train_X])
test_X = np.asarray([img_to_array(array_to_img(im, scale = False).resize((48, 48))) for im in test_X])

train_X = train_X / 255.
test_X = test_X / 255.
train_X = train_X.astype('float32')
test_X = test_X.astype('float32')

train_X, valid_X, train_Y, val_Y = train_test_split(train_X,train_Y,test_size = 0.2,random_state = 13)

train_X = preprocess_input(train_X)
valid_X = preprocess_input(valid_X)
test_X  = preprocess_input(test_X)

model = VGG16(weights = 'imagenet',
                  include_top = False, 
                  input_shape = (IMG_HEIGHT, IMG_WIDTH, IMG_DEPTH)
                 )
model.summary()

train_features = model.predict(np.array(train_X), batch_size = BATCH_SIZE, verbose = 1)
test_features = model.predict(np.array(test_X), batch_size = BATCH_SIZE, verbose = 1)
val_features = model.predict(np.array(valid_X), batch_size = BATCH_SIZE, verbose = 1)

mnist_train_features_vgg = np.reshape(train_features, (33600, 512))
mnist_test_features_vgg = np.reshape(test_features, (9999, 512))
mnist_val_features_vgg = np.reshape(val_features, (8400, 512))

mnist_pca_train_features = StandardScaler().fit_transform(mnist_train_features_vgg)
pca = PCA(n_components = 3)
mnist_pca_train_features = pca.fit_transform(mnist_pca_train_features)

KMC = KMeans(n_clusters = 10)
KMC.fit(mnist_pca_train_features)

fig = plt.figure(1,figsize=(8,6))
plt.clf()
ax = Axes3D(fig, rect = [0,0,0.95,1],elev = 48,azim = 134)

plt.cla()
ax.scatter(mnist_pca_train_features[:,[0]], mnist_pca_train_features[:,[1]], mnist_pca_train_features[:,[2]], c = KMC.labels_.astype(np.float))

plt.savefig('mnist-train.png')

mnist_pca_test_features = StandardScaler().fit_transform(mnist_test_features_vgg)
pca = PCA(n_components = 3)
mnist_pca_test_features = pca.fit_transform(mnist_pca_test_features)

KMC = KMeans(n_clusters = 10)
KMC.fit(mnist_pca_test_features)

fig = plt.figure(1,figsize=(8,6))
plt.clf()
ax = Axes3D(fig, rect = [0,0,0.95,1],elev = 48,azim = 134)

plt.cla()
ax.scatter(mnist_pca_test_features[:,[0]], mnist_pca_test_features[:,[1]], mnist_pca_test_features[:,[2]], c = KMC.labels_.astype(np.float))

plt.savefig('mnist-test.png')

mnist_pca_val_features = StandardScaler().fit_transform(mnist_val_features_vgg)
pca = PCA(n_components = 3)
mnist_pca_val_features = pca.fit_transform(mnist_pca_val_features)

KMC = KMeans(n_clusters = 10)
KMC.fit(mnist_pca_val_features)

fig = plt.figure(1,figsize=(8,6))
plt.clf()
ax = Axes3D(fig, rect = [0,0,0.95,1],elev = 48,azim = 134)

plt.cla()
ax.scatter(mnist_pca_val_features[:,[0]], mnist_pca_val_features[:,[1]], mnist_pca_val_features[:,[2]], c = KMC.labels_.astype(np.float))

plt.show()

LR = LogisticRegression()
LR.fit(mnist_train_features_vgg, train_Y)
LR.score(mnist_val_features_vgg, valid_Y)
LR.score(mnist_test_features_vgg, test_Y)

RF = RandomForestClassifier(n_estimators = 25, criterion = 'gini')
RF.fit(mnist_train_features_vgg, train_Y)
RF.score(mnist_val_features_vgg, valid_Y)
RF.score(mnist_test_features_vgg, test_Y)

RF = RandomForestClassifier(n_estimators = 50, criterion = 'gini')
RF.fit(mnist_train_features_vgg, train_Y)
RF.score(mnist_val_features_vgg, valid_Y)
RF.score(mnist_test_features_vgg, test_Y)

RF = RandomForestClassifier(n_estimators = 100, criterion = 'gini')
RF.fit(mnist_train_features_vgg, train_Y)
RF.score(mnist_val_features_vgg, valid_Y)
RF.score(mnist_test_features_vgg, test_Y)

RF = RandomForestClassifier(n_estimators = 25, criterion = 'entropy')
RF.fit(mnist_train_features_vgg, train_Y)
RF.score(mnist_val_features_vgg, valid_Y)
RF.score(mnist_test_features_vgg, test_Y)

RF = RandomForestClassifier(n_estimators = 50, criterion = 'entropy')
RF.fit(mnist_train_features_vgg, train_Y)
RF.score(mnist_val_features_vgg, valid_Y)
RF.score(mnist_test_features_vgg, test_Y)

RF = RandomForestClassifier(n_estimators = 100, criterion = 'entropy')
RF.fit(mnist_train_features_vgg, train_Y)
RF.score(mnist_val_features_vgg, valid_Y)
RF.score(mnist_test_features_vgg, test_Y)

KNN = KNeighborsClassifier(n_neighbors = 3)
KNN.fit(mnist_train_features_vgg, train_Y)
KNN.score(mnist_val_features_vgg, valid_Y)
KNN.score(mnist_test_features_vgg, test_Y)

KNN = KNeighborsClassifier(n_neighbors = 5)
KNN.fit(mnist_train_features_vgg, train_Y)
KNN.score(mnist_val_features_vgg, valid_Y)
KNN.score(mnist_test_features_vgg, test_Y)

MLP = MLPClassifier(hidden_layer_sizes=(64,32), activation='relu', batch_size=64)
MLP.fit(mnist_train_features_vgg, train_Y)
MLP.score(mnist_val_features_vgg, valid_Y)
MLP.score(mnist_test_features_vgg, test_Y)

qda = QuadraticDiscriminantAnalysis()
y_pred = qda.fit(train_features, train_Y).predict(test_features)
accuracy_score(test_Y, y_pred)

pca=PCA()
X_transformed = pca.fit_transform(train_features)
qdaf = qdaf.fit(X_transformed, train_Y)

testX_transformed = pca.transform(test_features)
y_pred2 =  qdaf.predict(testX_transformed)
accuracy_score(test_Y, y_pred2)

clf = LinearSVC(random_state=0, penalty='l1', dual=False)
clf.fit(train_features, train_Y)
y_predlsvm = clf.predict(test_features)
accuracy_score(test_Y, y_predlsvm)

pca = PCA(n_components=15)
X_transformed = pca.fit_transform(train_features)

clfrbgpca = SVC(random_state=0)
clfrbgpca.fit(X_transformed, train_Y) 

testX_transformed = pca.transform(test_features)

y_predrbgpca = clfrbgpca.predict(testX_transformed)
accuracy_score(test_Y, y_predrbgpca)

clfsigpca = SVC(random_state=0, kernel='sigmoid')
clfsigpca.fit(X_transformed, train_Y) 

y_predsigpca=clfsigpca.predict(testX_transformed)
accuracy_score(test_Y, y_predsigpca)