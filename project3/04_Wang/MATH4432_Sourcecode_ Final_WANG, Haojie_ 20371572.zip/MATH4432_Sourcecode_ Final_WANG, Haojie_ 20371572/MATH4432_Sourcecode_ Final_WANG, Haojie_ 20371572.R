##########################################################################################
# MATH4432 project 3: How Much Is Your House Worth?
# Written by WANG,Haojie (20371572) 
# Email: hwangbw@ust.hk or h.wang@connect.ust.hk
# Last Revised: May 22, 2018
##########################################################################################


## Content
## 1.Load library and data
## 2.Data cleaning(for missing values)
## 3.Feature engineering 
## 4.Data preparation
## 5.Modeling with SVM, lasso, XGBoost
## 6.Write submisson files
## Acknowledgements

## -----------------------1.Load library and data------------------------------------

if (!require("pacman")) install.packages("pacman")
pacman::p_load(tidyverse, mice, e1071, Metrics, skimr)
library(ggplot2)
library(plyr)
library(dplyr)
library(corrplot)
library(caret)
library(gridExtra)
library(scales)
library(Rmisc)
library(ggrepel)
library(randomForest)
library(psych)
library(xgboost)

#setwd("E:/Dropbox/Dropbox/MATH 4432/Monthly project/mini-project3")
setwd("~/Dropbox/MATH 4432/Monthly project/mini-project3")
train = read.csv(file='train.csv',stringsAsFactors = FALSE)
test = read.csv(file='test.csv',stringsAsFactors = FALSE)

##-------------------------------------2.Data clean---------------------------------

# combine data together to clean
# train$IsTrainSet = TRUE
# test$IsTrainSet = FALSE
testid = test$Id
test$Id = NULL
train$Id = NULL
test$SalePrice = NA
full = rbind(train,test)
sp=rbind(train,test)
sp=sp$SalePrice

# Housekeeping on the data, like fixing typo's or spaces/"&" in categories (factor levels). 
# use data.table for quick fixing

full <- data.table(full)
full[YearRemodAdd > YrSold, YearRemodAdd:= YrSold] ## Fix typo
full[GarageYrBlt == 2207, GarageYrBlt:= 2007] ## Fix typo
full[MSSubClass  == 150, MSSubClass:= 160] ## 150 not in training set
full[Exterior1st  == "Wd Sdng", Exterior1st:= "WdSdng"] ## Fix spaces
full[Exterior2nd  == "Wd Sdng", Exterior2nd:= "WdSdng"] ## Fix spaces
full[Exterior2nd  == "Brk Cmn", Exterior2nd:= "BrkComm"] ## Fix typo
full[Exterior2nd  == "Wd Shng", Exterior2nd:= "WdShing"] ## Fix typo
full[RoofMatl  == "Tar&Grv", RoofMatl:= "TarGrv"] ## Fix '&'
full[RoofMatl  == "WdShngl", RoofMatl:= "WdShing"] ## See exterior
full <- data.frame(full)

# take a look at all variables with missing values
numericVars <- which(sapply(full, is.numeric))
numericVarNames <- names(numericVars)
NAvar <- which(colSums(is.na(full)) > 0)
sort(colSums(sapply(full[NAvar], is.na)), decreasing = TRUE)

# start taking care of missing values piece by piece
# PoolQC
full$PoolQC[is.na(full$PoolQC)] <- 'NoPo'
Qualities <- c('NoPo' = 0, 'Po' = 1, 'Fa' = 2, 'TA' = 3, 'Gd' = 4, 'Ex' = 5)
full$PoolQC<-as.integer(revalue(full$PoolQC, Qualities))
table(full$PoolQC)
full$PoolQC[2421] <- 2
full$PoolQC[2504] <- 3
full$PoolQC[2600] <- 2
sort(colSums(sapply(full[NAvar], is.na)), decreasing = TRUE)
# MiscFeature
full$MiscFeature[is.na(full$MiscFeature)] <- 'NoAv'
full$MiscFeature <- as.factor(full$MiscFeature)
sort(colSums(sapply(full[NAvar], is.na)), decreasing = TRUE)
# Alley
full$Alley[is.na(full$Alley)] <- 'NoAv'
full$Alley <- as.factor(full$Alley)
sort(colSums(sapply(full[NAvar], is.na)), decreasing = TRUE)
# Fence
full$Fence[is.na(full$Fence)] <- 'NoAv'
full$Fence <- as.factor(full$Fence)
sort(colSums(sapply(full[NAvar], is.na)), decreasing = TRUE)
# FireplaceQu
full$FireplaceQu[is.na(full$FireplaceQu)] <- 'NoFi'
Qualities <- c('NoFi' = 0, 'Po' = 1, 'Fa' = 2, 'TA' = 3, 'Gd' = 4, 'Ex' = 5)
full$FireplaceQu<-as.integer(revalue(full$FireplaceQu, Qualities))
table(full$FireplaceQu)
sort(colSums(sapply(full[NAvar], is.na)), decreasing = TRUE)
# GarageYrBlt
full$GarageYrBlt[is.na(full$GarageYrBlt)] <- full$YearBuilt[is.na(full$GarageYrBlt)]
sort(colSums(sapply(full[NAvar], is.na)), decreasing = TRUE)
# GarageCar&GarageArea 
kable(full[!is.na(full$GarageType) & is.na(full$GarageFinish), c('GarageCars', 'GarageArea', 'GarageType', 'GarageCond', 'GarageQual', 'GarageFinish')])
full$GarageCond[2127] <- names(sort(-table(full$GarageCond)))[1]
full$GarageQual[2127] <- names(sort(-table(full$GarageQual)))[1]
full$GarageFinish[2127] <- names(sort(-table(full$GarageFinish)))[1]
full$GarageCars[2577] <- 0
full$GarageArea[2577] <- 0
full$GarageType[2577] <- NA
sort(colSums(sapply(full[NAvar], is.na)), decreasing = TRUE)
# GarageType
full$GarageType[is.na(full$GarageType)] <- 'NoGa'
full$GarageType <- as.factor(full$GarageType)
sort(colSums(sapply(full[NAvar], is.na)), decreasing = TRUE)
# GarageFinsh
full$GarageFinish[is.na(full$GarageFinish)] <- 'NoGa'
Finish <- c('NoGa'=0, 'Unf'=1, 'RFn'=2, 'Fin'=3)
full$GarageFinish<-as.integer(revalue(full$GarageFinish, Finish))
table(full$GarageFinish)
sort(colSums(sapply(full[NAvar], is.na)), decreasing = TRUE)
# GarageQual
full$GarageQual[is.na(full$GarageQual)] <- 'NoGa'
Qualities <- c('NoGa' = 0, 'Po' = 1, 'Fa' = 2, 'TA' = 3, 'Gd' = 4, 'Ex' = 5)
full$GarageQual<-as.integer(revalue(full$GarageQual, Qualities))
sort(colSums(sapply(full[NAvar], is.na)), decreasing = TRUE)
# GarageCond
full$GarageCond[is.na(full$GarageCond)] <- 'NoGa'
full$GarageCond<-as.integer(revalue(full$GarageCond, Qualities))
sort(colSums(sapply(full[NAvar], is.na)), decreasing = TRUE)
# Six Basement variable
full[!is.na(full$BsmtFinType1) & (is.na(full$BsmtCond)|is.na(full$BsmtQual)|is.na(full$BsmtExposure)|is.na(full$BsmtFinType2)), c('BsmtQual', 'BsmtCond', 'BsmtExposure', 'BsmtFinType1', 'BsmtFinType2')]
full$BsmtFinType2[333] <- names(sort(-table(full$BsmtFinType2)))[1]
full$BsmtExposure[c(949, 1488, 2349)] <- names(sort(-table(full$BsmtExposure)))[1]
full$BsmtCond[c(2041, 2186, 2525)] <- names(sort(-table(full$BsmtCond)))[1]
full$BsmtQual[c(2218, 2219)] <- names(sort(-table(full$BsmtQual)))[1]
full[(is.na(full$BsmtFullBath)|is.na(full$BsmtHalfBath)|is.na(full$BsmtFinSF1)|is.na(full$BsmtFinSF2)|is.na(full$BsmtUnfSF)|is.na(full$TotalBsmtSF)), c('BsmtQual', 'BsmtFullBath', 'BsmtHalfBath', 'BsmtFinSF1', 'BsmtFinSF2', 'BsmtUnfSF', 'TotalBsmtSF')]
full$BsmtFullBath[is.na(full$BsmtFullBath)] <-0
full$BsmtHalfBath[is.na(full$BsmtHalfBath)] <-0
full$BsmtFinSF1[is.na(full$BsmtFinSF1)] <-0
full$BsmtFinSF2[is.na(full$BsmtFinSF2)] <-0
full$BsmtUnfSF[is.na(full$BsmtUnfSF)] <-0
full$TotalBsmtSF[is.na(full$TotalBsmtSF)] <-0
sort(colSums(sapply(full[NAvar], is.na)), decreasing = TRUE)
# Another four ordinal basement variables
full$BsmtQual[is.na(full$BsmtQual)] <- 'NoBs'
Qualities <- c('NoBs' = 0, 'Po' = 1, 'Fa' = 2, 'TA' = 3, 'Gd' = 4, 'Ex' = 5)
full$BsmtQual<-as.integer(revalue(full$BsmtQual, Qualities))
full$BsmtCond[is.na(full$BsmtCond)] <- 'NoBs'
full$BsmtCond<-as.integer(revalue(full$BsmtCond, Qualities))
full$BsmtExposure[is.na(full$BsmtExposure)] <- 'NoBs'
Exposure <- c('NoBs'=0, 'No'=1, 'Mn'=2, 'Av'=3, 'Gd'=4)
full$BsmtExposure<-as.integer(revalue(full$BsmtExposure, Exposure))
full$BsmtFinType1[is.na(full$BsmtFinType1)] <- 'NoBs'
FinType <- c('NoBs'=0, 'Unf'=1, 'LwQ'=2, 'Rec'=3, 'BLQ'=4, 'ALQ'=5, 'GLQ'=6)
full$BsmtFinType1<-as.integer(revalue(full$BsmtFinType1, FinType))
full$BsmtFinType2[is.na(full$BsmtFinType2)] <- 'NoBs'
FinType <- c('NoBs'=0, 'Unf'=1, 'LwQ'=2, 'Rec'=3, 'BLQ'=4, 'ALQ'=5, 'GLQ'=6)
full$BsmtFinType2<-as.integer(revalue(full$BsmtFinType2, FinType))
table(full$BsmtFinType2)
sort(colSums(sapply(full[NAvar], is.na)), decreasing = TRUE)
# MasVnrType&MasVnrArea
full[is.na(full$MasVnrType) & !is.na(full$MasVnrArea), c('MasVnrType', 'MasVnrArea')]
full$MasVnrType[2611] <- names(sort(-table(full$MasVnrType)))[2]
full[2611, c('MasVnrType', 'MasVnrArea')]
full$MasVnrType[is.na(full$MasVnrType)] <- 'None'
full$MasVnrType <- as.factor(full$MasVnrType)
full$MasVnrArea[is.na(full$MasVnrArea)] <-0
sort(colSums(sapply(full[NAvar], is.na)), decreasing = TRUE)
# MSZoning
full$MSZoning[is.na(full$MSZoning)] <- names(sort(-table(full$MSZoning)))[1]
full$MSZoning <- as.factor(full$MSZoning)
sort(colSums(sapply(full[NAvar], is.na)), decreasing = TRUE)
# KitchenQual
full$KitchenQual[is.na(full$KitchenQual)] <- 'TA'
full$KitchenQual<-as.integer(revalue(full$KitchenQual, Qualities))
sort(colSums(sapply(full[NAvar], is.na)), decreasing = TRUE)
# Functional
full$Functional[is.na(full$Functional)] <- names(sort(-table(full$Functional)))[1]
full$Functional <- as.integer(revalue(full$Functional, c('Sal'=0, 'Sev'=1, 'Maj2'=2, 'Maj1'=3, 'Mod'=4, 'Min2'=5, 'Min1'=6, 'Typ'=7)))
sort(colSums(sapply(full[NAvar], is.na)), decreasing = TRUE)
# Exterior1st & Exterior2nd
full$Exterior1st[is.na(full$Exterior1st)] <- names(sort(-table(full$Exterior1st)))[1]
full$Exterior1st <- as.factor(full$Exterior1st)
full$Exterior2nd[is.na(full$Exterior2nd)] <- names(sort(-table(full$Exterior2nd)))[1]
full$Exterior2nd <- as.factor(full$Exterior2nd)
sort(colSums(sapply(full[NAvar], is.na)), decreasing = TRUE)
# Electrical
full$Electrical[is.na(full$Electrical)] <- names(sort(-table(full$Electrical)))[1]
full$Electrical <- as.factor(full$Electrical)
sort(colSums(sapply(full[NAvar], is.na)), decreasing = TRUE)
# SaleType
full$SaleType[is.na(full$SaleType)] <- names(sort(-table(full$SaleType)))[1]
full$SaleType <- as.factor(full$SaleType)
sort(colSums(sapply(full[NAvar], is.na)), decreasing = TRUE)
# LotFrontage
full[,c('SalePrice')] <- NULL
micemod <- full %>% mice(method='rf')
full <- complete(micemod)
sort(colSums(sapply(full[NAvar], is.na)), decreasing = TRUE)
# Utilities
table(full$Utilities)
full$Utilities <- NULL
sort(colSums(sapply(full[NAvar], is.na)), decreasing = TRUE)


# Taking care of remain ordinal variables
full$ExterQual<-as.integer(revalue(full$ExterQual, Qualities))
full$ExterCond<-as.integer(revalue(full$ExterCond, Qualities))
full$HeatingQC<-as.integer(revalue(full$HeatingQC, Qualities))
full$CentralAir<-as.integer(revalue(full$CentralAir, c('N'=0, 'Y'=1)))
full$Street<-as.integer(revalue(full$Street, c('Grvl'=0, 'Pave'=1)))
full$PavedDrive<-as.integer(revalue(full$PavedDrive, c('N'=0, 'P'=1, 'Y'=2)))

# Taking care of remain char variables, turn them into factors
chr <- full[,sapply(full,is.character)]
nochr <- full[,!sapply(full,is.character)]
fac <- chr %>% lapply(as.factor) %>% as.data.frame()
full <- bind_cols(fac,nochr)
str(full)

# Changing some numeric variables into factors
# Month Sold and MSSubClass
str(full$MoSold)
full$MoSold <- as.factor(full$MoSold)
str(full$MSSubClass)
full$MSSubClass <- as.factor(full$MSSubClass)
full$SalePrice = sp

#correlarion analysis
numericVars <- which(sapply(full, is.numeric)) #index vector numeric variables
factorVars <- which(sapply(full, is.factor)) #index vector factor variables
full_numVar <- full[, numericVars]
cor_numVar <- cor(full_numVar, use="pairwise.complete.obs") #correlations of full numeric variables
cor_sorted <- as.matrix(sort(cor_numVar[,'SalePrice'], decreasing = TRUE))
CorHigh <- names(which(apply(cor_sorted, 1, function(x) abs(x)>0.5)))
cor_numVar <- cor_numVar[CorHigh, CorHigh]
corrplot.mixed(cor_numVar, tl.col="black", tl.pos = "lt", tl.cex = 0.7,cl.cex = .7, number.cex=.7)

#variable importance analysis
set.seed(0)
quick_RF <- randomForest(x=full[1:1460,-79], y=full$SalePrice[1:1460], ntree=100,importance=TRUE)
imp_RF <- importance(quick_RF)
imp_DF <- data.frame(Variables = row.names(imp_RF), MSE = imp_RF[,1])
imp_DF <- imp_DF[order(imp_DF$MSE, decreasing = TRUE),]
ggplot(imp_DF[1:20,], aes(x=reorder(Variables, MSE), y=MSE, fill=MSE)) + geom_bar(stat = 'identity') + labs(x = 'Variables', y= 'IncMSE(%)') + coord_flip() + theme(legend.position="none")

##-------------------------------------3.Feature engineering---------------------------------
full$SumBath <- full$FullBath + (full$HalfBath*0.5) + full$BsmtFullBath + (full$BsmtHalfBath*0.5)
full$Remod <- ifelse(full$YearBuilt==full$YearRemodAdd, 0, 1) #0=No Remodeling, 1=Remodeling
full$Age <- as.numeric(full$YrSold)-full$YearRemodAdd
full$YrSold <- as.factor(full$YrSold)
full$SumSF <- full$GrLivArea + full$TotalBsmtSF
full$SumPorchSF <- full$OpenPorchSF + full$EnclosedPorch + full$X3SsnPorch + full$ScreenPorch

#figures
ggplot(data=full[!is.na(full$SalePrice),], aes(x=as.factor(SumBath), y=SalePrice))+
  geom_point(col='black') + geom_smooth(method = "lm", se=FALSE, color="red", aes(group=1)) +
  scale_y_continuous(breaks= seq(0, 800000, by=100000), labels = comma)

ggplot(data=full[!is.na(full$SalePrice),], aes(x=Age, y=SalePrice))+
  geom_point(col='black') + geom_smooth(method = "lm", se=FALSE, color="red", aes(group=1)) +
  scale_y_continuous(breaks= seq(0, 800000, by=100000), labels = comma)

ggplot(data=full[!is.na(full$SalePrice),], aes(x=SumSF, y=SalePrice))+
  geom_point(col='black') + geom_smooth(method = "lm", se=FALSE, color="red", aes(group=1)) +
  scale_y_continuous(breaks= seq(0, 800000, by=100000), labels = comma)

##-------------------------------------4.Data preparation---------------------------------
# delete highly correlated variables
dropVars <- c('YearRemodAdd', 'GarageYrBlt', 'GarageArea', 'GarageCond', 'TotalBsmtSF', 'TotalRmsAbvGrd', 'BsmtFinSF1')
full <- full[,!(names(full) %in% dropVars)]

# delte outliers
full <- full[-c(524, 1299),]

# splitting the dataframe into two groups: one with all (true) numeric variables, 
# and another dataframe holding the (ordinal) factors.
numericVarNames <- numericVarNames[!(numericVarNames %in% c('MSSubClass', 'MoSold', 'YrSold', 'SalePrice', 'OverallQual', 'OverallCond'))] #numericVarNames was created before having done anything
numericVarNames <- append(numericVarNames, c('Age', 'SumPorchSF', 'SumBath', 'SumSF'))
DFnumeric <- full[, names(full) %in% numericVarNames]
DFfactors <- full[, !(names(full) %in% numericVarNames)]
DFfactors <- DFfactors[, names(DFfactors) != 'SalePrice']

# fix the skewness and normalize the data
for(i in 1:ncol(DFnumeric)){
  if (abs(skew(DFnumeric[,i]))>0.8){
    DFnumeric[,i] <- log(DFnumeric[,i] +1)
  }
}
PreNum <- preProcess(DFnumeric, method=c("center", "scale"))
DFnorm <- predict(PreNum, DFnumeric)

# One hot encoding
DFdummies <- as.data.frame(model.matrix(~., DFfactors))
dim(DFdummies)
# Removing levels with few or no observations in train or test
full$SalePrice=sp[-c(524, 1299)]
ZerocolTest <- which(colSums(DFdummies[(nrow(full[!is.na(full$SalePrice),])+1):nrow(full),])==0)
DFdummies <- DFdummies[,-ZerocolTest]
ZerocolTrain <- which(colSums(DFdummies[1:nrow(full[!is.na(full$SalePrice),]),])==0)
DFdummies <- DFdummies[,-ZerocolTrain]
fewOnes <- which(colSums(DFdummies[1:nrow(full[!is.na(full$SalePrice),]),])<10)
DFdummies <- DFdummies[,-fewOnes]
combined <- cbind(DFnorm, DFdummies)

# Dealing with skewness of SalePrice
full$SalePrice <- log(full$SalePrice) 
skew(full$SalePrice)

#seprate train and test
clean.train <- combined[!is.na(full$SalePrice),]
clean.test <- combined[is.na(full$SalePrice),]
# clean.train = full[full$IsTrainSet==TRUE,]
# clean.test = full[full$IsTrainSet==FALSE,]
# clean.train$IsTrainSet = NULL
# clean.test$IsTrainSet = NULL
# clean.test$SalePrice = NULL
# train_label=clean.train$SalePrice
# clean.train$SalePrice = NULL

##-------------------------------------5.Modeling with SVM, lasso, XGBoost---------------------------------

# SVM
set.seed(0)
svm.clean.train<-clean.train
svm.clean.train$SalePrice<-full$SalePrice[!is.na(full$SalePrice)]
svm_model<-svm(SalePrice~., data=svm.clean.train, cost = 3)
svm_pred <- predict(svm_model,newdata = clean.test)
predictions_cvm <- exp(svm_pred)
svmsolution <- data.frame(Id=testid,SalePrice=predictions_cvm)


# Lasso
set.seed(0)
my_control <-trainControl(method="cv", number=5)
lassoGrid <- expand.grid(alpha = 1, lambda = seq(0.001,0.1,by = 0.0005))
lasso_mod <- train(x=clean.train, y=full$SalePrice[!is.na(full$SalePrice)], method='glmnet', trControl= my_control, tuneGrid=lassoGrid) 
lasso_mod$bestTune
min(lasso_mod$results$RMSE)
LassoPred <- predict(lasso_mod, clean.test)
predictions_lasso <- exp(LassoPred)
Lassosolution <- data.frame(Id=testid,SalePrice=predictions_lasso)


#xgboost
xgb_grid = expand.grid(
  nrounds = 1000,
  eta = c(0.1, 0.05, 0.01),
  max_depth = c(2, 3, 4, 5, 6),
  gamma = 0,
  colsample_bytree=1,
  min_child_weight=c(1, 2, 3, 4 ,5),
  subsample=1
)
# codes below are for parameter tuning and results are shown
# xgb_caret <- train(x=clean.train, y=full$SalePrice[!is.na(full$SalePrice)], method='xgbTree', trControl= my_control, tuneGrid=xgb_grid)
# xgb_caret$bestTune
# # nrounds max_depth  eta gamma colsample_bytree min_child_weight subsample
# # 28    1000         2 0.05     0                1                3         1
label_train <- full$SalePrice[!is.na(full$SalePrice)]
dtrain <- xgb.DMatrix(data = as.matrix(clean.train), label= label_train)
dtest <- xgb.DMatrix(data = as.matrix(clean.test))
default_param<-list(
  objective = "reg:linear",
  booster = "gbtree",
  eta=0.05, 
  gamma=0,
  max_depth=2, 
  min_child_weight=3, 
  subsample=1,
  colsample_bytree=1
)
xgbcv <- xgb.cv( params = default_param, data = dtrain, nrounds = 500, nfold = 5, showsd = T, stratified = T, print_every_n = 40, early_stopping_rounds = 10, maximize = F)
xgb_mod <- xgb.train(data = dtrain, params=default_param, nrounds = 351)
XGBpred <- predict(xgb_mod, dtest)
predictions_XGB <- exp(XGBpred)
XGBsolution <- data.frame(Id=testid,SalePrice=predictions_XGB)

# Weighted ensemble using caret
# 
# trControl <- trainControl(
#   method="cv",
#   number=7,
#   savePredictions="final",
#   index=createResample(clean.train$OverallQual, 7),  
#   allowParallel =TRUE
# )
# #use XGB tuned parmeters
# xgbTreeGrid <- expand.grid(nrounds = 351, max_depth = 2, eta = 0.05, gamma = 0, colsample_bytree = 1.0,  subsample = 1.0, min_child_weight = 3)
# glmnetGridElastic <- expand.grid(.alpha = 0.3, .lambda = 0.009) 
# glmnetGridLasso <- expand.grid(.alpha = 1, .lambda = 0.02)
# #glmnetGridRidge <- expand.grid(.alpha = 0, .lambda = seq(0.001,0.1,by = 0.001))
# set.seed(0)
# #treatplan <- designTreatmentsZ(clean.train, minFraction = 0.01, rareCount = 0, features, verbose = FALSE)
# #train.full.treat <- prepare(treatplan, dframe = train.full.dt, codeRestriction = c("clean", "lev"))
# we.clean.train<-lapply(clean.train, as.numeric)
# # we.clean.train=na.omit(we.clean.train)
# # we.clean.train<- we.clean.train[-c(524, 1299),]
# we.clean.train$SalePrice=label_train
# modelList <<- caretList(
#   we.clean.train$SalePrice~.,
#   trControl=trControl,
#   metric="RMSE",
#   data=we.clean.train,
#   tuneList=list(
#     xgbTree = caretModelSpec(method="xgbTree",  tuneGrid = xgbTreeGrid, nthread = 8),
#     glmnet=caretModelSpec(method="glmnet", tuneGrid = glmnetGridElastic), ## Elastic
#     glmnet=caretModelSpec(method="glmnet", tuneGrid = glmnetGridLasso)## Lasso
#     #glmnet=caretModelSpec(method="glmnet", tuneGrid = glmnetGridRidge) ## Ridge
#   )
# )
# set.seed(0)
# greedyEnsemble <- caretEnsemble(
#   modelList, 
#   metric="RMSE",
#   trControl=trainControl(
#     number=7, method = "cv"
#   ))
# summary(greedyEnsemble)
# we_Pred <- predict(greedyEnsemble, newdata=clean.test)
# predictions_we <- exp(we_Pred)
# wesolution <- data.frame(Id=testid,SalePrice=predictions_we)

## --------------------------------6.write submmission files--------------------------------

write.csv(svmsolution,"svm_solution.csv",row.names = F)
write.csv(Lassosolution,"lasso_solution.csv",row.names = F)
write.csv(XGBsolution,"xgb_solution.csv",row.names = F)
# write.csv(wesolution,"we_solution.csv",row.names = F)

#########################end of source code######################################

# Acknowledgments
# 
# The following kernels heavily influenced techniques, ideas, and presentation of this kernel.
# Thus I want to thanks:
# House prices: Lasso, XGBoost, and a detailed EDA by Erik Bruin
# R data.table, glmnet, xgboost with caret by Bart Boerman
# Many others.
